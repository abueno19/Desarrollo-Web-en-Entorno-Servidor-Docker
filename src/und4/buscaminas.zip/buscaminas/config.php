<?php
$filas=10;
$columnas=10;
$minas=10;
$tablero=array();
